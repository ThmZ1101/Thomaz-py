import math

def calcular_seno_cosseno_tangente():
    """
    Calcula o seno, cosseno e tangente de um ângulo em graus.
    """
    try:
        # Solicita ao usuário para inserir o ângulo em graus
        angulo_graus = float(input("Digite o valor do ângulo em graus: "))

        # Converte o ângulo de graus para radianos
        angulo_radianos = math.radians(angulo_graus)

        # Calcula o seno, cosseno e tangente
        seno = math.sin(angulo_radianos)
        cosseno = math.cos(angulo_radianos)
        tangente = math.tan(angulo_radianos)

        # Exibe os resultados
        print(f"\nResultados para o ângulo de {angulo_graus} graus:")
        print(f"Seno: {seno:.4f}")
        print(f"Cosseno: {cosseno:.4f}")
        print(f"Tangente: {tangente:.4f}")

    except ValueError:
        print("Entrada inválida. Por favor, digite um número.")

# Chama a função para executar o programa
calcular_seno_cosseno_tangente()